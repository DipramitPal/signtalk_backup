<?php
//$updatedData = $_POST['newData'];
// please validate the data you are expecting for security
//file_put_contents('subscribe.json', $updatedData);
$inp = file_get_contents('subscribe.json');
$subscribers = json_decode($inp);
echo $subscribers[0][];
?>
<html>
<head>
<title> SignTalk | View Subscribers | LearnISL</title>
<link rel="icon" href="images/logo.webp" type="image/gif" sizes="16x16">
</head>
<body>
<table>
<tr>
<th>
EMAIL
</th>
</tr>
<?php
foreach($subscribers as $subscriber)
{
echo "<tr><td>";
print $subscriber;
echo $subscriber['email'];
echo "</td></tr>";
}

?>
</table>
</body>
</html>