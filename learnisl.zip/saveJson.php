<?php
$updatedData = $_POST['newData'];
// please validate the data you are expecting for security
//file_put_contents('subscribe.json', $updatedData);
$inp = file_get_contents('subscribe.json');
$tempArray = json_decode($inp);
$updatedData = json_decode($updatedData);
array_push($tempArray, $updatedData);
$jsonData = json_encode($tempArray);
file_put_contents('subscribe.json', $jsonData);
?>